# J.A.R.V.I.S — Build & Install Guide

A full Flutter source project for a JARVIS-style Android AI assistant:
voice input (wake button + speech-to-text), OpenAI-powered replies,
text-to-speech output, flashlight/app-launch/time commands, and a
futuristic neon-blue HUD UI with a pulsing reactive circle.

> ⚠️ Important: this project was generated in a sandbox without internet
> access or the Android SDK, so the APK itself was **not** compiled here.
> Follow the steps below on your own computer — it's a normal Flutter
> build, roughly 10–15 minutes the first time.

---

## 1. File structure

```
jarvis_assistant/
├── pubspec.yaml                     # dependencies
├── lib/
│   ├── main.dart                    # app entry point
│   ├── config/
│   │   └── api_config.dart          # <-- put your OpenAI API key here
│   ├── screens/
│   │   └── home_screen.dart         # main HUD screen + voice logic
│   ├── services/
│   │   ├── ai_service.dart          # OpenAI API calls
│   │   ├── voice_service.dart       # speech-to-text
│   │   ├── tts_service.dart         # text-to-speech
│   │   └── device_control_service.dart  # flashlight, open apps, time/date
│   └── widgets/
│       ├── pulsing_circle.dart      # animated reactive HUD circle
│       └── hud_panel.dart           # time/date/status panels
└── android/
    └── app/src/main/AndroidManifest.xml   # permissions
```

---

## 2. Requirements

- A computer (Windows/Mac/Linux)
- [Flutter SDK](https://docs.flutter.dev/get-started/install) 3.19+ installed
- Android Studio (for the Android SDK + an emulator, or to plug in a real phone)
- An OpenAI API key: https://platform.openai.com/api-keys
- A mid-range+ Android phone with USB debugging enabled (or an emulator)

Check your setup any time with:
```bash
flutter doctor
```
Fix anything it flags with a red ✗ before continuing.

---

## 3. Step-by-step setup

### Step 1 — Get the project onto your machine
Download/unzip the `jarvis_assistant` folder you received, then open a
terminal inside it.

### Step 2 — Install dependencies
```bash
flutter pub get
```

### Step 3 — Add your OpenAI API key
Open `lib/config/api_config.dart` and replace:
```dart
static const String openAiApiKey = "PUT_YOUR_OPENAI_API_KEY_HERE";
```
with your real key, e.g. `"sk-proj-...."`.

You can also change `openAiModel` (default `gpt-4o-mini`, cheap and fast)
and edit `systemPrompt` to change JARVIS's personality — this is where
you'd add lines like *"Oga, I don run am"* / *"Boss, done sharp sharp"*
if you want the Nigerian-personality bonus style. Example:

```dart
static const String systemPrompt = """
You are JARVIS, a loyal AI assistant with a Nigerian personality.
Call the user "Oga" or "boss". Use phrases like "I don run am" (done)
and "Boss, done sharp sharp" occasionally. Keep replies short since
they'll be spoken aloud.
""";
```

### Step 4 — Connect a device
- **Real phone**: Enable Developer Options → USB Debugging, plug in via USB, accept the RSA prompt.
- **Emulator**: Open Android Studio → Device Manager → create/start a Pixel emulator (API 33+ recommended for best speech recognition support).

Confirm it's detected:
```bash
flutter devices
```

### Step 5 — Run it (for testing/debugging)
```bash
flutter run
```
This installs a debug build straight to your device so you can test
mic permissions, wake behavior, flashlight, etc. before making the
final APK.

### Step 6 — Build the release APK
```bash
flutter build apk --release
```
When it finishes, your installable APK is at:
```
build/app/outputs/flutter-apk/app-release.apk
```

### Step 7 — Install the APK on your phone
Either:
```bash
adb install build/app/outputs/flutter-apk/app-release.apk
```
or copy the `app-release.apk` file to your phone (Google Drive, USB
transfer, email to yourself) and tap it to install. You'll need to
allow "install from unknown sources" the first time.

---

## 4. First run on the phone

1. Open the app — you'll see the black/neon HUD and hear
   *"Welcome back, boss. Systems online."*
2. Grant the **microphone** permission when prompted (required for voice).
3. Grant the **camera** permission when prompted (required only for flashlight).
4. Tap the glowing mic button and speak, e.g.:
   - "What time is it?"
   - "Turn on the flashlight"
   - "Open WhatsApp"
   - "Tell me a joke" (goes to the AI)

---

## 5. Wake word ("Jarvis") setup — Picovoice Porcupine

The app now listens hands-free for the word **"Jarvis"** using
Picovoice Porcupine, running fully on-device (no audio ever leaves
the phone for wake-word detection). "Jarvis" is one of Porcupine's
built-in keywords, so no custom model training is needed.

### Get your free access key
1. Sign up at https://console.picovoice.ai (free tier is enough for personal use).
2. On the dashboard, copy your **AccessKey**.
3. Open `lib/config/api_config.dart` and paste it in:
   ```dart
   static const String picovoiceAccessKey = "YOUR_KEY_HERE";
   ```
4. Run `flutter pub get` again if you haven't already after pulling the update.

That's it — on next launch, after the "Welcome back, boss" greeting,
the HUD status will show **STANDBY · SAY "JARVIS"**, and saying the
word will trigger listening automatically, same as tapping the mic.

### How it works / mic hand-off
Only one thing can use the microphone at a time, so the app hands
control back and forth automatically:
1. Porcupine listens quietly in the background for "Jarvis".
2. On detection, Porcupine pauses and `speech_to_text` takes over to
   capture your actual command.
3. After JARVIS finishes speaking its reply, Porcupine resumes
   listening for the wake word.

You can still always use the tap-to-speak mic button — both methods
work side by side, and the app is fully functional even with no
Picovoice key set (it just falls back to tap-to-speak only, and logs
a friendly message instead of crashing).

### Important limitation
This wake-word listening only runs while the app is **open in the
foreground with the screen on**, *unless* you enable **Always-On mode**
— see the next section.

### Troubleshooting
- Status still shows plain "STANDBY" with no wake word mention → key
  is missing/invalid, or mic permission was denied. Check `flutter run`
  console output for a line starting with `Wake word:`.
- False triggers or missed detections → background noise affects
  accuracy; speak clearly and check Picovoice's console for sensitivity
  tuning options if needed.

---

## 6. Always-On mode — true background wake word (screen off / app minimized)

By default, wake-word listening pauses when you leave the app or lock
the screen (Android suspends microphone access for background apps).
**Always-On mode** fixes this by running JARVIS's whole listen → think
→ speak loop inside a real Android **foreground service** — the same
mechanism music players and navigation apps use to keep running with
the screen off.

### How to turn it on
1. Make sure your Picovoice key (`picovoiceAccessKey`) is set — Always-On mode needs it.
2. Run the app, grant the microphone permission.
3. Flip the **"ALWAYS-ON (SCREEN OFF)"** switch near the top of the HUD.
4. You'll be asked for a **notifications permission** — this is required
   by Android: any foreground service that uses the microphone must show
   an ongoing notification while it's active, so you (and the OS) always
   know it's listening. You'll see a persistent "JARVIS — Standing by"
   notification while Always-On mode is on.
5. Say "Jarvis" any time — screen locked, app closed, doesn't matter —
   and it will respond, same as before.

Turn the switch off any time to stop the background service and drop
back to the lighter in-app-only mode. Your preference is remembered
between app launches (stored locally via `shared_preferences`).

### What actually changed technically
- `lib/services/background_service.dart` — new. Configures and runs an
  Android foreground service (via the `flutter_background_service`
  package) with `foregroundServiceType="microphone"`. All of Porcupine,
  `speech_to_text`, `flutter_tts`, and the OpenAI call now run *inside
  that service's isolate*, not the app's UI isolate, so they keep
  working when the UI isn't active.
- `AndroidManifest.xml` — added `FOREGROUND_SERVICE`,
  `FOREGROUND_SERVICE_MICROPHONE`, and `POST_NOTIFICATIONS` permissions,
  plus the service declaration itself.
- `home_screen.dart` — when Always-On mode is on, the UI stops touching
  the microphone directly. It just listens to a broadcast stream
  (`BackgroundService.updates`) from the service and mirrors whatever
  state it reports (listening/thinking/speaking) onto the HUD circle.
  Tapping the mic button sends a `manualWake` event to the service
  instead of starting local speech recognition, so there's only ever
  one thing touching the mic at a time.

### Things to know before you rely on this
- **Battery**: continuous on-device wake-word detection is efficient
  (Porcupine is built for this), but a foreground service running
  24/7 does use more battery than nothing running at all. It's
  comparable to leaving a music app paused in the background.
- **OEM battery optimization**: some phones (Xiaomi, Huawei, Samsung's
  aggressive modes, etc.) kill background services to save battery
  regardless of foreground-service status. If Always-On mode stops
  working after a while, check your phone's battery settings and
  allow JARVIS to "run in background" / disable battery optimization
  for it.
- **The persistent notification is mandatory**, not optional — it's
  an Android platform requirement for any app listening to the mic in
  the background, precisely so users always know when they're being
  listened to. It can't be hidden while Always-On mode is active.
- **Android 14+** additionally wants a matching `foregroundServiceType`
  declared both in the manifest and when the service starts — both are
  set to `microphone` in this project already.
- This is Android-only, as noted in `background_service.dart`
  (`IosConfiguration` is present only so the plugin compiles cleanly;
  iOS doesn't allow this kind of persistent background microphone
  access at all).

---

## 6. Dependencies used (already in `pubspec.yaml`)

| Package | Purpose |
|---|---|
| `speech_to_text` | Voice input / speech recognition |
| `flutter_tts` | Text-to-speech voice output |
| `http` | Calling the OpenAI API |
| `permission_handler` | Requesting mic/camera permissions |
| `torch_light` | Flashlight on/off |
| `url_launcher` / `android_intent_plus` | Opening apps (WhatsApp, YouTube, Chrome) |
| `shared_preferences` | Local storage (ready for saving settings) |
| `intl` | Formatting time/date |

---

## 7. Customizing the look

- Colors: search for `0xFF00E5FF` (neon blue) across `lib/widgets/` and
  `lib/screens/home_screen.dart` to change the HUD color scheme.
- Animated circle behavior: `lib/widgets/pulsing_circle.dart`
  (`JarvisState`: idle / listening / thinking / speaking each get a
  different glow color and pulse speed).
- Startup line / responses: edit strings directly in
  `home_screen.dart` (`_bootSequence`) and `device_control_service.dart`.

---

## 8. Testing checklist

- [ ] App launches, plays "Welcome back, boss" on open
- [ ] Mic button turns the circle blue and pulses while listening
- [ ] "What time is it?" answers correctly
- [ ] "Turn on the flashlight" / "turn off the flashlight" works (needs camera permission)
- [ ] "Open WhatsApp" / "Open YouTube" / "Open Chrome" launches the app (must be installed)
- [ ] A general question ("what's the capital of France?") gets an AI-generated spoken answer
- [ ] Works with screen on, mid-range device, without major lag
- [ ] Always-On switch turns on, notification permission prompt appears, persistent "JARVIS — Standing by" notification shows
- [ ] With Always-On on, lock the screen, say "Jarvis", confirm it responds and speaks with the screen still off
- [ ] Turning Always-On off stops the notification and hands control back to tap-to-speak

---

## 9. Performance notes

- Uses on-device Android speech recognition (not a heavy cloud audio
  upload), so it's fast and battery-light.
- AI calls use `gpt-4o-mini` by default — cheap and low-latency. Swap
  to `gpt-4o` in `api_config.dart` for higher quality replies if you
  don't mind extra cost/latency.
- No background services running when idle — the app only listens or
  calls the API when you tap the mic, so battery drain at rest is
  minimal.

---

## 10. Security note on the API key

Hardcoding your OpenAI key in `api_config.dart` is fine for a personal
build you install on your own phone. If you ever plan to share this
APK with others, **do not** ship your key inside it — anyone could
extract it and run up your bill. Instead, put the OpenAI call behind
your own small backend server and have the app call that server.
