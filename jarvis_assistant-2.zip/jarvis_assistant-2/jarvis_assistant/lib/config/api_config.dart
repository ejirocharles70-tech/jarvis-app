/// ============================================================
///  PUT YOUR OPENAI API KEY HERE
/// ============================================================
/// Get a key from: https://platform.openai.com/api-keys
///
/// ⚠️ For a real published app, do NOT hardcode a key like this.
/// This is fine for personal/beginner builds. For production,
/// route requests through your own backend server instead.
class ApiConfig {
  static const String openAiApiKey = "PUT_YOUR_OPENAI_API_KEY_HERE";

  static const String openAiModel = "gpt-4o-mini";
  static const String openAiUrl = "https://api.openai.com/v1/chat/completions";

  /// ============================================================
  ///  WAKE WORD ("Hey Jarvis") — Picovoice Porcupine
  /// ============================================================
  /// 1. Sign up free at https://console.picovoice.ai
  /// 2. Copy your "AccessKey" from the console dashboard
  /// 3. Paste it below. "Jarvis" is a built-in Porcupine keyword,
  ///    so no custom training/model file is required.
  static const String picovoiceAccessKey = "PUT_YOUR_PICOVOICE_ACCESS_KEY_HERE";

  /// Master switch — set to false to disable wake-word listening
  /// entirely and rely only on the tap-to-speak mic button.
  static const bool wakeWordEnabled = true;

  /// JARVIS's personality / system prompt.
  /// Edit this to change how JARVIS talks to you.
  static const String systemPrompt = """
You are JARVIS, a witty, loyal, highly capable personal AI assistant,
inspired by Tony Stark's AI. You call the user "boss". You are concise,
confident, and slightly formal but warm. Keep spoken replies short
(1-3 sentences) since they will be read aloud by text-to-speech.
""";
}
