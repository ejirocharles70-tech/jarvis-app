import 'package:intl/intl.dart';
import 'package:torch_light/torch_light.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';

/// Result of trying to handle a command locally (without calling the AI).
class CommandResult {
  final bool handled;
  final String response;
  CommandResult(this.handled, this.response);
}

class DeviceControlService {
  bool _flashOn = false;

  /// Tries to handle simple device commands locally.
  /// Returns handled=false if the AI should answer instead.
  Future<CommandResult> tryHandle(String rawText) async {
    final text = rawText.toLowerCase().trim();

    // ---- Time & Date ----
    if (text.contains("what time") || text.contains("current time")) {
      final time = DateFormat('h:mm a').format(DateTime.now());
      return CommandResult(true, "It's $time, boss.");
    }
    if (text.contains("what date") ||
        text.contains("today's date") ||
        text.contains("what day is it")) {
      final date = DateFormat('EEEE, MMMM d, y').format(DateTime.now());
      return CommandResult(true, "Today is $date, boss.");
    }

    // ---- Flashlight ----
    if (text.contains("flashlight") || text.contains("torch")) {
      if (text.contains("off")) {
        try {
          await TorchLight.disableTorch();
          _flashOn = false;
          return CommandResult(true, "Flashlight off, boss.");
        } catch (_) {
          return CommandResult(true, "Couldn't turn off the flashlight, boss.");
        }
      } else {
        try {
          await TorchLight.enableTorch();
          _flashOn = true;
          return CommandResult(true, "Flashlight on, boss.");
        } catch (_) {
          return CommandResult(true, "Couldn't turn on the flashlight, boss.");
        }
      }
    }

    // ---- Open apps ----
    if (text.contains("open whatsapp")) {
      final opened = await _openApp("com.whatsapp");
      return CommandResult(true, opened ? "Opening WhatsApp, boss." : "WhatsApp isn't installed, boss.");
    }
    if (text.contains("open youtube") || text.contains("play music")) {
      final opened = await _openApp("com.google.android.youtube");
      return CommandResult(true, opened ? "Opening YouTube, boss." : "YouTube isn't installed, boss.");
    }
    if (text.contains("open chrome") || text.contains("open browser")) {
      final opened = await _openApp("com.android.chrome");
      return CommandResult(true, opened ? "Opening Chrome, boss." : "Couldn't open the browser, boss.");
    }
    if (text.contains("open camera")) {
      final opened = await _openApp("com.android.camera");
      return CommandResult(true, opened ? "Opening camera, boss." : "Couldn't open the camera, boss.");
    }

    // Not a recognized device command — let the AI handle it.
    return CommandResult(false, "");
  }

  Future<bool> _openApp(String packageName) async {
    try {
      final intent = AndroidIntent(
        action: 'action_main',
        package: packageName,
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      return true;
    } catch (_) {
      // Fallback: try a market/browser link
      try {
        final uri = Uri.parse("market://details?id=$packageName");
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri);
        }
      } catch (_) {}
      return false;
    }
  }

  bool get isFlashOn => _flashOn;
}
