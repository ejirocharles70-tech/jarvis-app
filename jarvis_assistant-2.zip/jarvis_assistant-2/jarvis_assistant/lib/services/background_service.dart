import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:porcupine_flutter/porcupine_manager.dart';
import 'package:porcupine_flutter/porcupine_error.dart';

import 'ai_service.dart';
import 'device_control_service.dart';
import '../config/api_config.dart';

const String _channelId = 'jarvis_foreground';
const int _notificationId = 888;

/// Runs JARVIS's whole listen → think → speak loop inside a real
/// Android foreground service, so the wake word ("Jarvis") keeps
/// working with the screen off or the app minimized — not just while
/// the app is open, the way the earlier in-app version worked.
///
/// The UI (home_screen.dart) doesn't touch the mic directly anymore
/// when this is running — it just displays whatever state this
/// service broadcasts, and can send a "manualWake" event to simulate
/// the tap-to-speak button.
class BackgroundService {
  static final FlutterBackgroundService _service = FlutterBackgroundService();

  /// Call once at app startup (see main.dart), before runApp.
  static Future<void> initialize() async {
    final notifications = FlutterLocalNotificationsPlugin();
    const channel = AndroidNotificationChannel(
      _channelId,
      'JARVIS Assistant',
      description: 'Keeps JARVIS listening for the wake word in the background',
      importance: Importance.low,
    );
    await notifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    await _service.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: _onStart,
        autoStart: false,
        isForegroundMode: true,
        notificationChannelId: _channelId,
        initialNotificationTitle: 'JARVIS',
        initialNotificationContent: 'Standing by…',
        foregroundServiceNotificationId: _notificationId,
        foregroundServiceTypes: [AndroidForegroundType.microphone],
      ),
      iosConfiguration: IosConfiguration(autoStart: false),
    );
  }

  /// Starts always-on listening. Requires RECORD_AUDIO + POST_NOTIFICATIONS
  /// permissions to already be granted (handle that in the UI first).
  static Future<void> start() async {
    if (!await _service.isRunning()) {
      await _service.startService();
    }
  }

  static Future<void> stop() async {
    _service.invoke('stopService');
  }

  static Future<bool> isRunning() => _service.isRunning();

  /// Broadcasts of {'state': ..., 'text': ...} from the service, so the
  /// UI can mirror what's happening (listening/thinking/speaking/idle).
  static Stream<Map<String, dynamic>?> get updates => _service.on('update');

  /// Simulates a wake-word trigger — used by the mic button in the UI
  /// so tap-to-speak and always-on wake word share one code path.
  static void triggerManualListen() => _service.invoke('manualWake');

  // ────────────────────────────────────────────────────────────
  // Everything below this line runs in a SEPARATE background
  // isolate managed by Android, independent of the app's UI.
  // ────────────────────────────────────────────────────────────
  @pragma('vm:entry-point')
  static void _onStart(ServiceInstance service) async {
    DartPluginRegistrant.ensureInitialized();

    if (service is AndroidServiceInstance) {
      service.setAsForegroundService();
    }

    final stt.SpeechToText speech = stt.SpeechToText();
    final FlutterTts tts = FlutterTts();
    final AiService ai = AiService();
    final DeviceControlService device = DeviceControlService();
    PorcupineManager? porcupine;
    bool sttReady = false;

    await tts.setLanguage("en-US");
    await tts.setSpeechRate(0.48);
    await tts.setPitch(0.9);
    sttReady = await speech.initialize();

    void broadcast(String state, String text) {
      service.invoke('update', {'state': state, 'text': text});
    }

    void updateNotification(String text) {
      if (service is AndroidServiceInstance) {
        service.setForegroundNotificationInfo(title: "JARVIS", content: text);
      }
    }

    Future<void> speak(String text) async {
      broadcast('speaking', text);
      updateNotification(text.length > 60 ? '${text.substring(0, 60)}…' : text);
      final completer = Completer<void>();
      tts.setCompletionHandler(() {
        if (!completer.isCompleted) completer.complete();
      });
      await tts.speak(text);
      await completer.future.timeout(const Duration(seconds: 30), onTimeout: () {});
      broadcast('idle', 'Standing by…');
      updateNotification('Standing by — say "Jarvis"');
    }

    Future<void> handleCommand(String text) async {
      if (text.trim().isEmpty) {
        await speak("I didn't catch that, boss.");
        return;
      }
      broadcast('thinking', 'You: $text');
      updateNotification('Thinking…');

      final result = await device.tryHandle(text);
      if (result.handled) {
        await speak(result.response);
        return;
      }
      final reply = await ai.ask(text);
      await speak(reply);
    }

    Future<void> listenForCommand() async {
      broadcast('listening', 'Listening, boss…');
      updateNotification('Listening…');

      if (!sttReady) sttReady = await speech.initialize();
      if (!sttReady) {
        await speak("My speech recognizer isn't available right now, boss.");
        return;
      }

      final completer = Completer<String>();
      await speech.listen(
        onResult: (r) {
          if (r.finalResult && !completer.isCompleted) {
            completer.complete(r.recognizedWords);
          }
        },
        listenFor: const Duration(seconds: 20),
        pauseFor: const Duration(seconds: 3),
      );

      final text = await completer.future.timeout(
        const Duration(seconds: 25),
        onTimeout: () => "",
      );
      await speech.stop();
      await handleCommand(text);
    }

    Future<void> startPorcupine() async {
      if (ApiConfig.picovoiceAccessKey == "PUT_YOUR_PICOVOICE_ACCESS_KEY_HERE" ||
          ApiConfig.picovoiceAccessKey.isEmpty) {
        broadcast('error', 'No Picovoice key set — always-on wake word disabled.');
        updateNotification('Wake word disabled — tap mic in-app instead');
        return;
      }
      try {
        porcupine = await PorcupineManager.fromBuiltInKeywords(
          ApiConfig.picovoiceAccessKey,
          [BuiltInKeyword.JARVIS],
          (keywordIndex) async {
            await porcupine?.stop();
            await listenForCommand();
            await porcupine?.start();
          },
          errorCallback: (err) => broadcast('error', 'Wake word error: $err'),
        );
        await porcupine!.start();
        updateNotification('Standing by — say "Jarvis"');
      } on PorcupineException catch (e) {
        broadcast('error', 'Wake word init failed: ${e.message}');
      }
    }

    // Manual trigger from the UI's mic button.
    service.on('manualWake').listen((event) async {
      await porcupine?.stop();
      await listenForCommand();
      await porcupine?.start();
    });

    // Clean shutdown when the user disables always-on mode.
    service.on('stopService').listen((event) async {
      await porcupine?.stop();
      await porcupine?.delete();
      await speech.stop();
      service.stopSelf();
    });

    await startPorcupine();
    broadcast('idle', 'Standing by…');
  }
}
