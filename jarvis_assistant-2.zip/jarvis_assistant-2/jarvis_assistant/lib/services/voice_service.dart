import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';

class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isInitialized = false;

  Future<bool> init() async {
    final micStatus = await Permission.microphone.request();
    if (!micStatus.isGranted) return false;

    _isInitialized = await _speech.initialize(
      onError: (err) => print("Speech error: $err"),
      onStatus: (status) => print("Speech status: $status"),
    );
    return _isInitialized;
  }

  bool get isListening => _speech.isListening;
  bool get isAvailable => _isInitialized;

  /// Starts listening. Calls [onResult] with the recognized text
  /// once the user finishes speaking (finalResult == true).
  Future<void> startListening({
    required Function(String text) onResult,
    required Function(String partial) onPartial,
  }) async {
    if (!_isInitialized) {
      final ok = await init();
      if (!ok) return;
    }

    await _speech.listen(
      onResult: (result) {
        if (result.finalResult) {
          onResult(result.recognizedWords);
        } else {
          onPartial(result.recognizedWords);
        }
      },
      listenFor: const Duration(seconds: 20),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      cancelOnError: true,
      listenMode: stt.ListenMode.confirmation,
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }
}
