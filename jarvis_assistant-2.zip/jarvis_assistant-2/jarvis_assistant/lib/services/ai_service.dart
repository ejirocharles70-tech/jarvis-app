import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class AiService {
  final List<Map<String, String>> _history = [
    {"role": "system", "content": ApiConfig.systemPrompt},
  ];

  /// Sends [userText] to OpenAI and returns JARVIS's reply.
  Future<String> ask(String userText) async {
    if (ApiConfig.openAiApiKey == "PUT_YOUR_OPENAI_API_KEY_HERE" ||
        ApiConfig.openAiApiKey.isEmpty) {
      return "Boss, you haven't added your OpenAI API key yet. "
          "Open lib/config/api_config.dart and paste it in.";
    }

    _history.add({"role": "user", "content": userText});

    try {
      final response = await http.post(
        Uri.parse(ApiConfig.openAiUrl),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${ApiConfig.openAiApiKey}",
        },
        body: jsonEncode({
          "model": ApiConfig.openAiModel,
          "messages": _history,
          "temperature": 0.7,
          "max_tokens": 300,
        }),
      );

      if (response.statusCode != 200) {
        return "Boss, I hit an error talking to the AI service "
            "(code ${response.statusCode}). Please check your API key or network.";
      }

      final data = jsonDecode(response.body);
      final reply = data["choices"][0]["message"]["content"] as String;
      _history.add({"role": "assistant", "content": reply});

      // Keep history from growing unbounded
      if (_history.length > 20) {
        _history.removeRange(1, 3);
      }

      return reply.trim();
    } catch (e) {
      return "Boss, something went wrong reaching the AI: $e";
    }
  }

  void resetConversation() {
    _history.removeRange(1, _history.length);
  }
}
