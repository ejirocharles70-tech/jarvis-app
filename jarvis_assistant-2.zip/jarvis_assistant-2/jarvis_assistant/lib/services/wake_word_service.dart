import 'package:porcupine_flutter/porcupine_manager.dart';
import 'package:porcupine_flutter/porcupine_error.dart';
import 'package:porcupine_flutter/porcupine.dart';
import 'package:permission_handler/permission_handler.dart';
import '../config/api_config.dart';

/// Listens continuously (while the app is open/foreground) for the
/// wake word "Jarvis" using Picovoice Porcupine, and fires [onWake]
/// when it's detected.
///
/// NOTE: This only listens while the app is in the foreground/screen
/// is on. True always-on background wake-word detection requires
/// running this inside an Android foreground service — see
/// BUILD_GUIDE.md for notes on extending this further.
class WakeWordService {
  PorcupineManager? _manager;
  bool _isActive = false;
  bool _isSupported = true;

  bool get isActive => _isActive;
  bool get isSupported => _isSupported;

  /// Starts listening for the wake word. [onWake] is called each time
  /// "Jarvis" is detected. [onError] is called if setup fails (e.g.
  /// missing/invalid access key or missing mic permission).
  Future<void> start({
    required Function() onWake,
    required Function(String message) onError,
  }) async {
    if (!ApiConfig.wakeWordEnabled) {
      _isSupported = false;
      onError("Wake word is disabled in config.");
      return;
    }

    if (ApiConfig.picovoiceAccessKey == "PUT_YOUR_PICOVOICE_ACCESS_KEY_HERE" ||
        ApiConfig.picovoiceAccessKey.isEmpty) {
      _isSupported = false;
      onError(
          "No Picovoice access key set — wake word disabled. Add one in api_config.dart.");
      return;
    }

    final micStatus = await Permission.microphone.request();
    if (!micStatus.isGranted) {
      _isSupported = false;
      onError("Microphone permission denied — wake word disabled.");
      return;
    }

    try {
      _manager = await PorcupineManager.fromBuiltInKeywords(
        ApiConfig.picovoiceAccessKey,
        [BuiltInKeyword.JARVIS],
        (keywordIndex) => onWake(),
        errorCallback: (error) => onError("Wake word error: $error"),
      );
      await _manager!.start();
      _isActive = true;
    } on PorcupineException catch (e) {
      _isSupported = false;
      onError("Couldn't start wake word engine: ${e.message}");
    }
  }

  /// Temporarily pause listening (e.g. while speech-to-text or TTS
  /// needs exclusive access to the microphone/speaker).
  Future<void> pause() async {
    if (_manager != null && _isActive) {
      await _manager!.stop();
      _isActive = false;
    }
  }

  /// Resume listening for the wake word after a pause.
  Future<void> resume() async {
    if (_manager != null && !_isActive) {
      await _manager!.start();
      _isActive = true;
    }
  }

  Future<void> dispose() async {
    await _manager?.stop();
    await _manager?.delete();
    _isActive = false;
  }
}
