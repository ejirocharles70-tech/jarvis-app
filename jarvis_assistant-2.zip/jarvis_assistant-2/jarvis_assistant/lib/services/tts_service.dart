import 'package:flutter_tts/flutter_tts.dart';

class TtsService {
  final FlutterTts _tts = FlutterTts();
  bool _ready = false;

  Future<void> init() async {
    await _tts.setLanguage("en-US");
    await _tts.setSpeechRate(0.48);
    await _tts.setPitch(0.9); // slightly deeper, more "JARVIS"
    await _tts.setVolume(1.0);
    _ready = true;
  }

  Future<void> speak(String text, {Function()? onDone}) async {
    if (!_ready) await init();
    _tts.setCompletionHandler(() {
      if (onDone != null) onDone();
    });
    await _tts.speak(text);
  }

  Future<void> stop() async => _tts.stop();
}
