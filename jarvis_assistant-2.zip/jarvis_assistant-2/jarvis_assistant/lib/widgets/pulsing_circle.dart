import 'dart:math';
import 'package:flutter/material.dart';

enum JarvisState { idle, listening, thinking, speaking }

class PulsingCircle extends StatefulWidget {
  final JarvisState state;
  const PulsingCircle({super.key, required this.state});

  @override
  State<PulsingCircle> createState() => _PulsingCircleState();
}

class _PulsingCircleState extends State<PulsingCircle>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _rotateController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _rotateController.dispose();
    super.dispose();
  }

  Color get _glowColor {
    switch (widget.state) {
      case JarvisState.listening:
        return const Color(0xFF00E5FF);
      case JarvisState.thinking:
        return const Color(0xFFAB47FF);
      case JarvisState.speaking:
        return const Color(0xFF00FFC6);
      case JarvisState.idle:
        return const Color(0xFF0091EA);
    }
  }

  double get _baseScale {
    switch (widget.state) {
      case JarvisState.listening:
        return 1.15;
      case JarvisState.thinking:
        return 1.05;
      case JarvisState.speaking:
        return 1.1;
      case JarvisState.idle:
        return 1.0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseController, _rotateController]),
      builder: (context, _) {
        final pulse = 0.9 + (_pulseController.value * 0.2 * _baseScale);
        return SizedBox(
          width: 260,
          height: 260,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer rotating ring
              Transform.rotate(
                angle: _rotateController.value * 2 * pi,
                child: Container(
                  width: 230,
                  height: 230,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _glowColor.withOpacity(0.35),
                      width: 1.5,
                    ),
                  ),
                ),
              ),
              // Glow halo
              Container(
                width: 190 * pulse,
                height: 190 * pulse,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _glowColor.withOpacity(0.55),
                      blurRadius: 40,
                      spreadRadius: 6,
                    ),
                  ],
                ),
              ),
              // Core circle
              Container(
                width: 150 * pulse,
                height: 150 * pulse,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      _glowColor.withOpacity(0.9),
                      _glowColor.withOpacity(0.15),
                      Colors.black,
                    ],
                  ),
                  border: Border.all(color: _glowColor, width: 2),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
