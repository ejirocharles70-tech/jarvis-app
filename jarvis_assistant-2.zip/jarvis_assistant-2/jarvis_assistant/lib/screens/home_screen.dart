import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/ai_service.dart';
import '../services/voice_service.dart';
import '../services/tts_service.dart';
import '../services/device_control_service.dart';
import '../services/wake_word_service.dart';
import '../services/background_service.dart';
import '../widgets/pulsing_circle.dart';
import '../widgets/hud_panel.dart';

const String _alwaysOnPrefKey = 'jarvis_always_on_mode';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Foreground-only path (used when Always-On mode is OFF)
  final VoiceService _voice = VoiceService();
  final TtsService _tts = TtsService();
  final AiService _ai = AiService();
  final DeviceControlService _device = DeviceControlService();
  final WakeWordService _wakeWord = WakeWordService();

  StreamSubscription<Map<String, dynamic>?>? _serviceSub;

  JarvisState _state = JarvisState.idle;
  String _displayText = "Tap the mic and speak, or say \"Jarvis\" to begin.";
  String _partialText = "";
  Timer? _clockTimer;
  String _time = "";
  String _date = "";
  bool _wakeWordReady = false;
  bool _alwaysOnMode = false;
  bool _togglingAlwaysOn = false;

  @override
  void initState() {
    super.initState();
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
    _restoreAlwaysOnPreference();
  }

  void _updateClock() {
    final now = DateTime.now();
    setState(() {
      _time = DateFormat('h:mm:ss a').format(now);
      _date = DateFormat('EEEE, MMM d, y').format(now);
    });
  }

  Future<void> _restoreAlwaysOnPreference() async {
    final prefs = await SharedPreferences.getInstance();
    final wanted = prefs.getBool(_alwaysOnPrefKey) ?? false;
    if (wanted) {
      await _enableAlwaysOn(showBootMessage: true);
    } else {
      await _bootSequenceForegroundOnly();
    }
  }

  // ── Foreground-only boot (Always-On OFF) ──────────────────────────
  Future<void> _bootSequenceForegroundOnly() async {
    await _tts.init();
    await Future.delayed(const Duration(milliseconds: 400));
    await _speak("Welcome back, boss. Systems online.");
    _startInAppWakeWordListening();
  }

  void _startInAppWakeWordListening() {
    _wakeWord.start(
      onWake: _onWakeDetected,
      onError: (message) {
        debugPrint("Wake word: $message");
        if (mounted) setState(() => _wakeWordReady = false);
      },
    );
    setState(() => _wakeWordReady = true);
  }

  Future<void> _onWakeDetected() async {
    if (_state != JarvisState.idle || _voice.isListening) return;
    await _wakeWord.pause();
    await _beginListening();
  }

  Future<void> _beginListening() async {
    setState(() {
      _state = JarvisState.listening;
      _partialText = "";
      _displayText = "Listening, boss...";
    });
    await _voice.startListening(
      onPartial: (text) => setState(() => _partialText = text),
      onResult: (text) => _handleUserSpeech(text),
    );
  }

  Future<void> _speak(String text) async {
    setState(() {
      _state = JarvisState.speaking;
      _displayText = text;
    });
    await _tts.speak(text, onDone: () async {
      if (mounted) setState(() => _state = JarvisState.idle);
      await _wakeWord.resume();
    });
  }

  Future<void> _handleUserSpeech(String text) async {
    if (text.trim().isEmpty) {
      setState(() {
        _state = JarvisState.idle;
        _displayText = "I didn't catch that, boss. Try again.";
      });
      await _wakeWord.resume();
      return;
    }
    setState(() {
      _state = JarvisState.thinking;
      _displayText = "You: $text";
    });
    final commandResult = await _device.tryHandle(text);
    if (commandResult.handled) {
      await _speak(commandResult.response);
      return;
    }
    final reply = await _ai.ask(text);
    await _speak(reply);
  }

  // ── Mic button (works in both modes) ───────────────────────────────
  Future<void> _onMicTapped() async {
    if (_alwaysOnMode) {
      // Hand off to the background service's shared listen pipeline.
      BackgroundService.triggerManualListen();
      return;
    }
    if (_voice.isListening) {
      await _voice.stopListening();
      setState(() => _state = JarvisState.idle);
      await _wakeWord.resume();
      return;
    }
    await _wakeWord.pause();
    await _beginListening();
  }

  // ── Always-On mode toggle ──────────────────────────────────────────
  Future<void> _toggleAlwaysOn(bool value) async {
    setState(() => _togglingAlwaysOn = true);
    final prefs = await SharedPreferences.getInstance();

    if (value) {
      final ok = await _enableAlwaysOn(showBootMessage: false);
      if (ok) await prefs.setBool(_alwaysOnPrefKey, true);
    } else {
      await _disableAlwaysOn();
      await prefs.setBool(_alwaysOnPrefKey, false);
    }
    setState(() => _togglingAlwaysOn = false);
  }

  Future<bool> _enableAlwaysOn({required bool showBootMessage}) async {
    final micStatus = await Permission.microphone.request();
    final notifStatus = await Permission.notification.request();

    if (!micStatus.isGranted) {
      if (mounted) {
        setState(() => _displayText =
            "I need microphone access to run always-on, boss.");
      }
      return false;
    }
    // Notification permission denial isn't fatal on older Android
    // versions, but the ongoing notification may be silently hidden.
    if (!notifStatus.isGranted) {
      debugPrint("Notification permission not granted — foreground "
          "service notification may not be visible.");
    }

    // Tear down the foreground-only path so only one thing owns the mic.
    await _wakeWord.dispose();
    await _voice.stopListening();

    await BackgroundService.start();
    _serviceSub?.cancel();
    _serviceSub = BackgroundService.updates.listen(_onServiceUpdate);

    setState(() {
      _alwaysOnMode = true;
      _wakeWordReady = true;
      _displayText = "Always-on mode active, boss. I'm listening even "
          "with the screen off.";
    });

    if (showBootMessage) {
      // The service itself doesn't speak a greeting on resume-from-boot,
      // so give a quick in-app confirmation instead.
      setState(() => _state = JarvisState.idle);
    }
    return true;
  }

  Future<void> _disableAlwaysOn() async {
    await BackgroundService.stop();
    await _serviceSub?.cancel();
    _serviceSub = null;

    setState(() {
      _alwaysOnMode = false;
      _state = JarvisState.idle;
      _displayText = "Always-on mode off. Back to tap-to-speak, boss.";
    });

    // Resume the lightweight in-app path.
    await _tts.init();
    _startInAppWakeWordListening();
  }

  void _onServiceUpdate(Map<String, dynamic>? event) {
    if (event == null || !mounted) return;
    final stateStr = event['state'] as String? ?? 'idle';
    final text = event['text'] as String? ?? '';

    JarvisState newState;
    switch (stateStr) {
      case 'listening':
        newState = JarvisState.listening;
        break;
      case 'thinking':
        newState = JarvisState.thinking;
        break;
      case 'speaking':
        newState = JarvisState.speaking;
        break;
      case 'error':
        newState = JarvisState.idle;
        break;
      default:
        newState = JarvisState.idle;
    }

    setState(() {
      _state = newState;
      _displayText = text.isNotEmpty ? text : _displayText;
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _wakeWord.dispose();
    _serviceSub?.cancel();
    super.dispose();
  }

  String get _statusLabel {
    switch (_state) {
      case JarvisState.listening:
        return "LISTENING";
      case JarvisState.thinking:
        return "PROCESSING";
      case JarvisState.speaking:
        return "SPEAKING";
      case JarvisState.idle:
        if (_alwaysOnMode) return "ALWAYS-ON · SAY \"JARVIS\"";
        return _wakeWordReady ? "STANDBY · SAY \"JARVIS\"" : "STANDBY";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              // Top bar
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "J.A.R.V.I.S",
                    style: TextStyle(
                      color: Color(0xFF00E5FF),
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 4,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFF00E5FF)),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _statusLabel,
                      style: const TextStyle(
                        color: Color(0xFF00E5FF),
                        fontSize: 11,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Time / Date panels
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  HudPanel(title: "Time", value: _time),
                  HudPanel(title: "Date", value: _date),
                ],
              ),
              const SizedBox(height: 10),

              // Always-on mode toggle
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "ALWAYS-ON (SCREEN OFF)",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                        letterSpacing: 1,
                      ),
                    ),
                    _togglingAlwaysOn
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF00E5FF),
                            ),
                          )
                        : Switch(
                            value: _alwaysOnMode,
                            activeColor: const Color(0xFF00E5FF),
                            onChanged: _toggleAlwaysOn,
                          ),
                  ],
                ),
              ),

              const Spacer(),

              // Central animated circle
              GestureDetector(
                onTap: _onMicTapped,
                child: PulsingCircle(state: _state),
              ),

              const SizedBox(height: 10),
              if (_partialText.isNotEmpty)
                Text(
                  _partialText,
                  style: const TextStyle(color: Colors.white54, fontSize: 14),
                  textAlign: TextAlign.center,
                ),

              const Spacer(),

              // Response / transcript display
              Container(
                width: double.infinity,
                constraints: const BoxConstraints(minHeight: 80),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
                ),
                child: Text(
                  _displayText,
                  style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4),
                ),
              ),

              const SizedBox(height: 18),

              // Mic button
              GestureDetector(
                onTap: _onMicTapped,
                child: Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (_voice.isListening || _state == JarvisState.listening)
                        ? const Color(0xFF00E5FF)
                        : Colors.black,
                    border: Border.all(color: const Color(0xFF00E5FF), width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF00E5FF).withOpacity(0.5),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.mic,
                    color: (_voice.isListening || _state == JarvisState.listening)
                        ? Colors.black
                        : const Color(0xFF00E5FF),
                    size: 32,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
